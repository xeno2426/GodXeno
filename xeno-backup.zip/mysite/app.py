# ---------- PART 1 of 3 ----------
from flask import Flask, request, redirect, session, Response, send_from_directory, url_for
from datetime import datetime
import json, os, hashlib, secrets
from werkzeug.utils import secure_filename

# ---------- CONFIG ----------
BASE_DIR = os.path.dirname(__file__)
DATA_DIR = os.path.join(BASE_DIR, "data")
NOTES_DIR = os.path.join(DATA_DIR, "notes")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(NOTES_DIR, exist_ok=True)

USERS_FILE = os.path.join(DATA_DIR, "users.json")
ADMIN_KEY = "XENO-ADMIN-2426"   # admin reset key (change if you want)

# ---------- FLASK APP ----------
app = Flask(__name__)
app.secret_key = "CHANGE_THIS_SECRET_KEY"  # change for production

# ---------- HELPERS ----------
def load_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return default

def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def load_users():
    return load_json(USERS_FILE, {})

def save_users(users):
    save_json(USERS_FILE, users)

def user_dir(username: str):
    d = os.path.join(DATA_DIR, username)
    os.makedirs(d, exist_ok=True)
    os.makedirs(os.path.join(d, "uploads"), exist_ok=True)
    return d

def uploads_dir(username: str):
    return os.path.join(DATA_DIR, username, "uploads")

def notes_file(username: str):
    return os.path.join(NOTES_DIR, f"{username}_notes.json")

def load_notes(username: str):
    return load_json(notes_file(username), [])

def save_notes(username: str, notes):
    save_json(notes_file(username), notes)

def chats_file(u1: str, u2: str):
    a, b = sorted([u1, u2])
    return os.path.join(DATA_DIR, f"chat_{a}__{b}.json")

def load_chat(u1: str, u2: str):
    return load_json(chats_file(u1, u2), {"messages": [], "unread": {}})

def save_chat(u1: str, u2: str, data):
    save_json(chats_file(u1, u2), data)

def hash_pw(pw: str) -> str:
    return hashlib.sha256(pw.encode("utf-8")).hexdigest()

def current_user():
    return session.get("user")

def require_login():
    if not current_user():
        return redirect("/login")
    return None

# ---------- HTML TEMPLATE (UI A) ----------
HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Xeno WebApp</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
*{box-sizing:border-box}
body{margin:0;background:#020617;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#f1f5f9}
.app{min-height:100vh;padding:16px;display:flex;align-items:center;justify-content:center}
.card{width:100%;max-width:480px;background:rgba(15,23,42,0.96);border-radius:18px;box-shadow:0 18px 40px rgba(0,0,0,.7);padding:16px 16px 18px;border:1px solid rgba(148,163,184,.12)}
.nav{display:flex;margin-bottom:12px;border-radius:999px;background:rgba(15,23,42,.95);padding:4px}
.nav a{flex:1;text-align:center;text-decoration:none;padding:6px 0;color:#94a3b8;border-radius:999px;border:1px solid transparent;font-size:12px}
.nav a.active{color:#e5e7eb;background:rgba(56,189,248,.14);border-color:rgba(56,189,248,.4)}
.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.top span{font-size:13px;font-weight:600}
.top a{font-size:11px;color:#fca5a5;text-decoration:none}
h1{font-size:20px;margin:4px 0 4px}
p{font-size:13px;color:#94a3b8;margin:0 0 10px}
input,textarea,select{width:100%;background:#021025;color:#e5e7eb;border:1px solid #16202b;border-radius:10px;padding:9px 10px;font-size:13px;margin-bottom:10px;outline:none}
textarea{min-height:120px;resize:vertical}
.btn{width:100%;background:linear-gradient(135deg,#38bdf8,#6366f1);color:#020617;border:none;border-radius:999px;padding:9px;font-weight:600;font-size:14px;cursor:pointer}
.btn2{width:100%;background:transparent;color:#e5e7eb;border-radius:999px;padding:8px;border:1px solid #26303a;font-size:12px;margin-top:6px;cursor:pointer}
.btn-sm{display:inline-block;padding:8px 12px;border-radius:999px;background:linear-gradient(135deg,#38bdf8,#6366f1);color:#020617;text-decoration:none;font-weight:700}
.add-link{display:block;padding:10px 14px;border-radius:999px;background:linear-gradient(135deg,#38bdf8,#6366f1);color:#020617;text-decoration:none;font-weight:700;text-align:center;margin-top:10px}
.list{margin-top:8px;max-height:320px;overflow-y:auto}
.item{background:#021024;border-radius:12px;padding:10px;margin-bottom:8px;border:1px solid #131921}
.title{font-size:15px;font-weight:700}
.time{font-size:11px;opacity:.7;margin:4px 0}
.preview{font-size:13px;color:#cbd5e1}
.avatar{width:64px;height:64px;border-radius:999px;object-fit:cover;border:2px solid #334155;margin-bottom:6px}
.thumb{max-width:100%;max-height:120px;object-fit:cover;border-radius:10px;margin-top:4px}
.full-img{max-width:100%;border-radius:12px;margin:8px 0}
.error{background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.7);color:#fecaca;border-radius:10px;padding:6px 9px;font-size:12px;margin-bottom:8px}
.info{background:rgba(56,189,248,.08);border:1px solid rgba(56,189,248,.5);color:#bae6fd;border-radius:10px;padding:6px 9px;font-size:12px;margin-bottom:8px}
.chat-box{border-radius:12px;border:1px solid #19232b;padding:8px;max-height:320px;overflow-y:auto;background:rgba(2,6,23,.25);margin-bottom:8px}
.msg{margin-bottom:8px;padding:8px;border-radius:10px;font-size:13px;max-width:80%}
.msg.me{margin-left:auto;background:rgba(56,189,248,.18)}
.msg.them{margin-right:auto;background:rgba(30,64,175,.5)}
.helper{font-size:12px;color:#9ca3af}
.friend-item{display:flex;align-items:center;justify-content:space-between;padding:8px;border-radius:10px;background:#021024;border:1px solid #131921;margin-bottom:8px}
.badge{display:inline-block;background:#ef4444;color:white;border-radius:999px;padding:4px 8px;font-size:11px;margin-left:6px}
</style>
</head>
<body>
<div class="app">
  <div class="card">
    {TOP}
    {NAV}
    {CONTENT}
  </div>
</div>
</body>
</html>
"""

# ---------- RENDER ----------
def render(content, active="", user=None):
    def nav_link(name, href, label=None):
        if label is None:
            label = name.capitalize()
        cls = "active" if active == name else ""
        return f'<a href="{href}" class="{cls}">{label}</a>'

    # compute unread badge for Friends
    badge_html = ""
    me = user
    if me:
        users = load_users()
        total_unread = 0
        for other in users:
            if other == me:
                continue
            chat = load_chat(me, other)
            total_unread += int(chat.get("unread", {}).get(me, 0) or 0)
        if total_unread:
            badge_html = f' <span class="badge">{total_unread}</span>'

    if user:
        nav_html = (
            '<div class="nav">'
            + nav_link("home", "/")
            + nav_link("friends", "/friends", "Friends" + (badge_html or ""))
            + nav_link("profile", "/profile", "Profile")
            + "</div>"
        )
        top_html = f'<div class="top"><span><a href="/user/{user}" style="color:inherit;text-decoration:none">@{user}</a></span><a href="/logout">Logout</a></div>'
    else:
        nav_html = ""  # hide nav for login/signup
        top_html = '<div class="top"><span>Xeno WebApp</span><a href="/login">Login</a></div>'

    page = HTML.replace("{NAV}", nav_html).replace("{TOP}", top_html).replace("{CONTENT}", content)
    return page

# ---------- AUTH ROUTES ----------
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if current_user():
        return redirect("/")
    users = load_users()
    error = ""
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p1 = request.form.get("password", "")
        p2 = request.form.get("password2", "")
        if not u or not p1:
            error = "Username and password required."
        elif " " in u or len(u) < 3:
            error = "Username must be at least 3 chars, no spaces."
        elif u in users:
            error = "Username already exists."
        elif p1 != p2:
            error = "Passwords do not match."
        elif len(p1) < 4:
            error = "Password too short."
        else:
            users[u] = {"password_hash": hash_pw(p1), "bio": "", "avatar": "", "friends": []}
            save_users(users)
            user_dir(u)
            save_notes(u, [])
            session["user"] = u
            return redirect("/")
    msg = f'<div class="error">{error}</div>' if error else ""
    content = f"""
<h1>Create account</h1>
{msg}
<form method="post">
  <input name="username" placeholder="Username" required>
  <input type="password" name="password" placeholder="Password" required>
  <input type="password" name="password2" placeholder="Confirm password" required>
  <button class="btn" type="submit">Create account</button>
</form>
<form action="/login">
  <button class="btn2" type="submit">Back to login</button>
</form>
"""
    return render(content, active="", user=None)

@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect("/")
    users = load_users()
    error = ""
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        info = users.get(u)
        if not info:
            error = "User not found."
        elif info.get("password_hash") != hash_pw(p):
            error = "Wrong password."
        else:
            session["user"] = u
            return redirect("/")
    msg = f'<div class="error">{error}</div>' if error else ""
    content = f"""
<h1>Login</h1>
<p>Welcome back.</p>
{msg}
<form method="post">
  <input name="username" placeholder="Username" required>
  <input type="password" name="password" placeholder="Password" required>
  <button class="btn" type="submit">Login</button>
</form>
<form action="/signup">
  <button class="btn2" type="submit">Create account</button>
</form>
<form action="/reset_admin">
  <button class="btn2" type="submit">Reset password (admin key)</button>
</form>
"""
    return render(content, active="", user=None)

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

@app.route("/reset_admin", methods=["GET", "POST"])
def reset_admin():
    msg = ""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        key = request.form.get("adminkey", "").strip()
        p1 = request.form.get("password", "")
        p2 = request.form.get("password2", "")
        users = load_users()
        if key != ADMIN_KEY:
            msg = '<div class="error">Invalid admin key.</div>'
        elif username not in users:
            msg = '<div class="error">User not found.</div>'
        elif not p1 or p1 != p2:
            msg = '<div class="error">Passwords empty or do not match.</div>'
        elif len(p1) < 4:
            msg = '<div class="error">Password too short.</div>'
        else:
            users[username]["password_hash"] = hash_pw(p1)
            save_users(users)
            msg = '<div class="info">Password updated. You can login now.</div>'
    content = f"""
<h1>Reset password (admin key)</h1>
{msg}
<form method="post">
  <input name="username" placeholder="Username" required>
  <input name="adminkey" placeholder="Admin key" required>
  <input name="password" type="password" placeholder="New password" required>
  <input name="password2" type="password" placeholder="Confirm new password" required>
  <button class="btn" type="submit">Reset password</button>
</form>
<form action="/login">
  <button class="btn2" type="submit">Back to login</button>
</form>
"""
    return render(content, active="", user=None)
# ---------- END PART 1 ----------

# ---------- PART 2 of 3 ----------
# HOME & HISTORY
@app.route("/", methods=["GET", "POST"])
def home():
    guard = require_login()
    if guard:
        return guard
    u = current_user()
    if request.method == "POST":
        quick = request.form.get("quick", "").strip()
        if quick:
            with open(os.path.join(user_dir(u), "history.txt"), "a") as f:
                f.write(f"{datetime.now().isoformat()} - {quick}\n")
            return redirect("/")
    notes_list = list(reversed(load_notes(u)))
    items = ""
    for i, n in enumerate(notes_list):
        img_html = f"<img class='thumb' src='/uploads/{u}/{n.get('image')}' alt='attach'>" if n.get("image") else ""
        preview = (n.get("body","")[:120] + ("..." if len(n.get("body",""))>120 else ""))
        items += f"""
<div class="item">
  <div class="title">{n.get('title','(no title)')}</div>
  <div class="time">{n.get('time')}</div>
  <div class="preview">{preview}</div>
  {img_html}
  <div style="display:flex;gap:8px;margin-top:8px">
    <a class="btn-sm" href="/edit-note/{i}">Edit</a>
    <form method="post" action="/delete-note/{i}" style="margin:0;">
      <button class="btn2" type="submit">Delete</button>
    </form>
  </div>
</div>
"""
    content = f"""
<h1>Home</h1>
<p>Add quick note or create full note below.</p>
<form method="post">
  <input name="quick" placeholder="Quick note...">
  <button class="btn" type="submit">Save to history</button>
</form>
<hr>
<h2>Saved notes (most recent first)</h2>
<div class="list">{items or 'No saved notes yet.'}</div>
<a class="add-link" href="/notes">Add new note</a>
"""
    return render(content, active="home", user=u)

@app.route("/history")
def history():
    guard = require_login()
    if guard:
        return guard
    u = current_user()
    hf = os.path.join(user_dir(u), "history.txt")
    lines = []
    if os.path.exists(hf):
        with open(hf, "r") as f:
            lines = f.readlines()
    items = "".join(f"<div class='item'>{line.strip()}</div>" for line in reversed(lines))
    content = f"<h1>History</h1><div class='list'>{items or 'No history yet.'}</div>"
    return render(content, active="home", user=u)

# NOTES create/edit/delete/view
@app.route("/notes", methods=["GET", "POST"])
def notes():
    guard = require_login()
    if guard:
        return guard
    u = current_user()
    if request.method == "POST":
        title = request.form.get("title","").strip() or "(no title)"
        body = request.form.get("body","")
        file = request.files.get("image")
        fname = ""
        if file and file.filename:
            safe = secure_filename(file.filename)
            fname = datetime.now().strftime("%Y%m%d%H%M%S_") + safe
            os.makedirs(uploads_dir(u), exist_ok=True)
            file.save(os.path.join(uploads_dir(u), fname))
        notes = load_notes(u)
        notes.append({"title": title, "body": body, "time": datetime.now().strftime("%Y-%m-%d %H:%M"), "image": fname})
        save_notes(u, notes)
        return redirect("/")
    content = """
<h1>New note</h1>
<form method="post" enctype="multipart/form-data">
  <input name="title" placeholder="Title">
  <textarea name="body" placeholder="Write your note..."></textarea>
  <input type="file" name="image" accept="image/*,audio/*,video/*">
  <button class="btn" type="submit">Save note</button>
</form>
"""
    return render(content, active="home", user=u)

@app.route("/edit-note/<int:index>", methods=["GET","POST"])
def edit_note(index):
    guard = require_login()
    if guard:
        return guard
    u = current_user()
    notes = load_notes(u)
    if index < 0 or index >= len(notes):
        return redirect("/")
    note = notes[index]
    if request.method == "POST":
        note["title"] = request.form.get("title", note.get("title","")).strip()
        note["body"] = request.form.get("body", note.get("body",""))
        file = request.files.get("image")
        if file and file.filename:
            safe = secure_filename(file.filename)
            fname = datetime.now().strftime("%Y%m%d%H%M%S_") + safe
            os.makedirs(uploads_dir(u), exist_ok=True)
            file.save(os.path.join(uploads_dir(u), fname))
            note["image"] = fname
        notes[index] = note
        save_notes(u, notes)
        return redirect("/")
    img_html = f"<img class='thumb' src='/uploads/{u}/{note.get('image')}' alt='attach'>" if note.get("image") else ""
    content = f"""
<h1>Edit note</h1>
<form method="post" enctype="multipart/form-data">
  <input name="title" value="{note.get('title','')}">
  <textarea name="body">{note.get('body','')}</textarea>
  {img_html}
  <input type="file" name="image" accept="image/*,audio/*,video/*">
  <button class="btn" type="submit">Save changes</button>
</form>
"""
    return render(content, active="home", user=u)

@app.route("/delete-note/<int:index>", methods=["POST"])
def delete_note(index):
    guard = require_login()
    if guard:
        return guard
    u = current_user()
    notes = load_notes(u)
    if 0 <= index < len(notes):
        note = notes.pop(index)
        if note.get("image"):
            path = os.path.join(uploads_dir(u), note["image"])
            if os.path.exists(path):
                os.remove(path)
        save_notes(u, notes)
    return redirect("/")

@app.route("/note/<int:index>")
def note_view(index):
    guard = require_login()
    if guard:
        return guard
    u = current_user()
    notes = load_notes(u)
    if index < 0 or index >= len(notes):
        return redirect("/")
    n = notes[index]
    img_html = f"<img class='full-img' src='/uploads/{u}/{n.get('image')}'>" if n.get("image") else ""
    content = f"""
<h1>{n.get('title')}</h1>
<div class="time">{n.get('time')}</div>
{img_html}
<div class="full">{n.get('body')}</div>
<p><a href='/' style='font-size:12px;color:#93c5fd;text-decoration:none;'>&larr; Back</a></p>
"""
    return render(content, active="home", user=u)

# PROFILE view + update
@app.route("/profile", methods=["GET","POST"])
def profile():
    guard = require_login()
    if guard:
        return guard
    u = current_user()
    users = load_users()
    info = users.get(u, {})
    msg = ""
    if request.method == "POST":
        bio = request.form.get("bio","").strip()
        info["bio"] = bio
        file = request.files.get("avatar")
        if file and file.filename:
            safe = secure_filename(file.filename)
            ext = os.path.splitext(safe)[1] or ".jpg"
            fname = f"avatar{ext}"
            os.makedirs(uploads_dir(u), exist_ok=True)
            file.save(os.path.join(uploads_dir(u), fname))
            info["avatar"] = fname
        users[u] = info
        save_users(users)
        msg = "Profile updated."
    avatar_html = f"<img class='avatar' src='/uploads/{u}/{info.get('avatar')}'>" if info.get("avatar") else "<div class='avatar' style='background:#0b1220;display:flex;align-items:center;justify-content:center;color:#9ca3af'>Avatar</div>"
    content = f"""
<h1>Profile</h1>
{avatar_html}
<p class='title'>@{u}</p>
<p class='preview'>Bio: {info.get('bio','No bio yet.')}</p>
<div class='info'>{msg if msg else ''}</div>
<form method="post" enctype="multipart/form-data">
  <textarea name="bio" placeholder="Your bio...">{info.get('bio','')}</textarea>
  <input type="file" name="avatar" accept="image/*">
  <button class="btn" type="submit">Save profile</button>
</form>
"""
    return render(content, active="profile", user=u)

# UPLOADS serve
@app.route("/uploads/<username>/<filename>")
def serve_uploads(username, filename):
    path = uploads_dir(username)
    return send_from_directory(path, filename)
# ---------- END PART 2 ----------

# ---------- PART 3 of 3 ----------
# PUBLIC user profile (view before adding friend)
@app.route("/user/<username>")
def user_profile(username):
    users = load_users()
    info = users.get(username)
    if not info:
        return redirect("/")
    avatar_html = f"<img class='avatar' src='/uploads/{username}/{info.get('avatar')}'>" if info.get("avatar") else "<div class='avatar' style='background:#0b1220;display:flex;align-items:center;justify-content:center;color:#9ca3af'>Avatar</div>"
    bio = info.get("bio","")
    me = current_user()
    actions = ""
    if me:
        if me == username:
            actions = "<p class='helper'>This is your profile.</p>"
        else:
            myinfo = load_users().get(me, {})
            if username in myinfo.get("friends", []):
                actions = f"<p><a class='btn' href='/chat/{username}'>Chat with {username}</a></p>"
            else:
                actions = f'''
<form method="post" action="/add-friend">
  <input type="hidden" name="friend" value="{username}">
  <button class="btn" type="submit">Add friend</button>
</form>
'''
    content = f"""
<h1>@{username}</h1>
{avatar_html}
<p class='preview'>{bio or 'No bio yet.'}</p>
{actions}
<p><a href="/friends" style="font-size:12px;color:#93c5fd;text-decoration:none;">&larr; Back</a></p>
"""
    return render(content, active="friends", user=me)

# ADD friend (POST)
@app.route("/add-friend", methods=["POST"])
def add_friend():
    guard = require_login()
    if guard:
        return guard
    me = current_user()
    friend = request.form.get("friend","").strip()
    users = load_users()
    if not friend or friend not in users or friend == me:
        return redirect("/friends")
    uinfo = users.get(me, {})
    pals = uinfo.get("friends", [])
    if friend not in pals:
        pals.append(friend)
        uinfo["friends"] = pals
        users[me] = uinfo
        save_users(users)
    return redirect(f"/user/{friend}")

# REMOVE friend
@app.route("/remove-friend/<friend>", methods=["POST"])
def remove_friend(friend):
    guard = require_login()
    if guard:
        return guard
    me = current_user()
    users = load_users()
    uinfo = users.get(me, {})
    pals = uinfo.get("friends", [])
    if friend in pals:
        pals.remove(friend)
        uinfo["friends"] = pals
        users[me] = uinfo
        save_users(users)
    return redirect("/friends")

# FRIENDS list
@app.route("/friends")
def friends():
    guard = require_login()
    if guard:
        return guard
    me = current_user()
    users = load_users()
    me_info = users.get(me, {})
    pals = me_info.get("friends", [])
    items = ""
    for p in pals:
        info = users.get(p,{})
        avatar_html = f"<img class='avatar' src='/uploads/{p}/{info.get('avatar')}' style='width:48px;height:48px;margin-right:8px;border-radius:999px'>" if info.get("avatar") else "<div style='width:48px;height:48px;border-radius:999px;background:#0b1220;margin-right:8px;display:inline-block'></div>"
        items += f"""
<div class='friend-item'>
  <div style='display:flex;align-items:center;gap:10px'>
    {avatar_html}
    <div><a href='/user/{p}' style='color:#93c5fd;text-decoration:none'>@{p}</a><div class='preview' style='margin-top:4px'>{info.get('bio','')[:60]}</div></div>
  </div>
  <div style='display:flex;flex-direction:column;gap:6px'>
    <a class='btn2' href='/chat/{p}'>Chat</a>
    <form method='post' action='/remove-friend/{p}' style='margin:0;'><button class='btn2' type='submit'>Remove</button></form>
  </div>
</div>
"""
    content = f"""
<h1>Friends</h1>
<p>Your friends list.</p>
<div class='list'>{items or 'No friends yet.'}</div>
"""
    return render(content, active="friends", user=me)

# CHAT send + view
@app.route("/chat/<friend>", methods=["GET","POST"])
def chat(friend):
    guard = require_login()
    if guard:
        return guard
    me = current_user()
    users = load_users()
    if friend not in users:
        return redirect("/friends")
    # require friend relationship (optional) - allow only if friend in my list
    if friend not in users.get(me, {}).get("friends", []):
        return redirect(f"/user/{friend}")
    # POST: send message
    if request.method == "POST":
        txt = request.form.get("message","").strip()
        file = request.files.get("file")
        fname = ""
        ftype = ""
        if file and file.filename:
            safe = secure_filename(file.filename)
            fname = datetime.now().strftime("%Y%m%d%H%M%S_") + safe
            os.makedirs(uploads_dir(me), exist_ok=True)
            file.save(os.path.join(uploads_dir(me), fname))
            ext = safe.lower()
            if ext.endswith((".jpg",".jpeg",".png",".gif")):
                ftype = "image"
            elif ext.endswith((".mp3",".wav",".m4a",".ogg")):
                ftype = "audio"
            elif ext.endswith((".mp4",".webm",".mov")):
                ftype = "video"
            else:
                ftype = "file"
        chatdata = load_chat(me, friend)
        chatdata["messages"].append({"from":me,"to":friend,"time":datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"text":txt,"file":fname,"ftype":ftype})
        # increment unread counter for recipient
        unread = chatdata.get("unread", {})
        unread[friend] = unread.get(friend, 0) + 1
        chatdata["unread"] = unread
        save_chat(me, friend, chatdata)
        return redirect(f"/chat/{friend}")
    # GET: show chat, clear unread for me
    chatdata = load_chat(me, friend)
    if chatdata.get("unread", {}).get(me):
        chatdata["unread"][me] = 0
        save_chat(me, friend, chatdata)
    msgs = chatdata.get("messages", [])
    bubbles = []
    for m in msgs:
        cls = "me" if m.get("from")==me else "them"
        text_html = m.get("text","")
        file_html = ""
        if m.get("file"):
            url = f"/uploads/{m.get('from')}/{m.get('file')}"
            if m.get("ftype") == "image":
                file_html = f"<div><img class='thumb' src='{url}'></div>"
            elif m.get("ftype") == "audio":
                file_html = f"<div><audio controls src='{url}'></audio></div>"
            elif m.get("ftype") == "video":
                file_html = f"<div><video controls style='max-width:100%' src='{url}'></video></div>"
            else:
                file_html = f"<div><a href='{url}' style='color:#93c5fd'>Download</a></div>"
        bubbles.append(f"<div class='msg {'me' if cls=='me' else 'them'}'><b>{m.get('from')}</b><br>{text_html}{file_html}<small>{m.get('time')}</small></div>")
    chat_html = "".join(bubbles) or "<div class='helper'>No messages yet.</div>"
    content = f"""
<h1>Chat with @{friend}</h1>
<p>Send messages, voice, images, videos or documents.</p>
<div class='chat-box'>{chat_html}</div>
<form method='post' enctype='multipart/form-data'>
  <div class='chat-input-row' style='display:flex;gap:6px'>
    <input name='message' type='text' placeholder='Type a message...' style='flex:1'>
    <input name='file' type='file' accept='image/*,audio/*,video/*,application/pdf'>
  </div>
  <p class='helper'>Attach image, audio (voice), video or document.</p>
  <button class='btn' type='submit'>Send</button>
</form>
"""
    return render(content, active="friends", user=me)

# ensure minimal files exist then run
if __name__ == "__main__":
    if not os.path.exists(USERS_FILE):
        save_users({})
    app.run(debug=True)
# ---------- END PART 3 ----------